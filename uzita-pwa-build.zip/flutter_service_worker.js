'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"canvaskit/canvaskit.js": "728b2d477d9b8c14593d4f9b82b484f3",
"canvaskit/canvaskit.js.symbols": "bdcd3835edf8586b6d6edfce8749fb77",
"canvaskit/canvaskit.wasm": "7a3f4ae7d65fc1de6a6e7ddd3224bc93",
"canvaskit/chromium/canvaskit.js": "8191e843020c832c9cf8852a4b909d4c",
"canvaskit/chromium/canvaskit.js.symbols": "b61b5f4673c9698029fa0a746a9ad581",
"canvaskit/chromium/canvaskit.wasm": "f504de372e31c8031018a9ec0a9ef5f0",
"canvaskit/skwasm.js": "ea559890a088fe28b4ddf70e17e60052",
"canvaskit/skwasm.js.symbols": "e72c79950c8a8483d826a7f0560573a1",
"canvaskit/skwasm.wasm": "39dd80367a4e71582d234948adc521c0",
"canvaskit/skwasm_heavy.js": "413f5b2b2d9345f37de148e2544f584f",
"canvaskit/skwasm_heavy.js.symbols": "3c01ec03b5de6d62c34e17014d1decd3",
"canvaskit/skwasm_heavy.wasm": "8034ad26ba2485dab2fd49bdd786837b",
"flutter.js": "83d881c1dbb6d6bcd6b42e274605b69c",
"flutter_bootstrap.js": "7cc9392e4e906d0381745f08a1f6d7c8",
"index.html": "a7f69ede4c5f1505f86973ec7a922e2e",
"/": "a7f69ede4c5f1505f86973ec7a922e2e",
"main.dart.js": "b00005c265538f6c10c046c76fd67e9a",
"version.json": "2d2b1edffdbdffafacc8ef08f17822ed",
"assets/assets/banner.jpg": "5cf46ce9cf8959cc76fda4ee93b1f388",
"assets/assets/biokaveh.png": "092088b62cd00808934beeea566ed6b0",
"assets/assets/logouzita.png": "d93ab90e6f22545c4285bce122942e27",
"assets/assets/app_icon_android.png": "41a8645d0ab3f80f281b165adc5bb292",
"assets/assets/fonts/Nasalization.otf": "663c62572f93cd595b9d1ac934720d99",
"assets/assets/fonts/InterFont/Inter%2520Regular.otf": "241349b41f6da6538b60c52a605ceb77",
"assets/assets/fonts/InterFont/Inter%2520Bold.otf": "9268fc2fdff5007bc0006c1ce926d27e",
"assets/assets/fonts/InterFont/Inter%2520Light.otf": "e0c09f596566b0086f25ad9a274c8e58",
"assets/assets/fonts/InterFont/Inter%2520Medium.otf": "b29de20b8c21e8ee3537c5c0475089a3",
"assets/assets/fonts/InterFont/Inter%2520SemiBold.otf": "b748d4680e203c2e500854e4064dcfff",
"assets/assets/fonts/InterFont/Inter%2520ExtraBold.otf": "82308f933b1c340843056f94ee259642",
"assets/assets/fonts/InterFont/Inter%2520Black.otf": "509dd1f48e3a32cd2425a9d7e699899b",
"assets/assets/fonts/vazir-font-v16.1.0/Vazir.ttf": "398b39dd0060814801cd1cbfe43fe0b5",
"assets/assets/fonts/vazir-font-v16.1.0/Vazir-Light.ttf": "00f48b2a2bde26034df6e71ef3efadfe",
"assets/assets/fonts/vazir-font-v16.1.0/Vazir-Bold.ttf": "8cea4a72681429a50b77de1d8aa609f3",
"assets/assets/fonts/vazir-font-v16.1.0/Vazir-Medium.ttf": "4a3887b6bfe4ed0fc41834d6e56b71ae",
"assets/assets/fonts/vazir-font-v16.1.0/Vazir-Thin.ttf": "e514f10989c43e8b8e0d81fac7aad163",
"assets/assets/icons/admin.svg": "078214f2588f32d970616d4087d14621",
"assets/assets/icons/device.svg": "99480d814af7660268c1c33de24b0571",
"assets/assets/icons/key.svg": "3211bc78aeb6efa68485a9fef822c32c",
"assets/assets/icons/office.svg": "5d7b44309c2a5f5797bb8af157dc3e4a",
"assets/assets/icons/person.svg": "3e198bfbc6132731bb95e69268ac022d",
"assets/assets/icons/phone-plus.svg": "46f24b07dedbc43d4a3c11f3e5659d3f",
"assets/assets/icons/report.svg": "bd96b5e32ae0a95a7279a3a3f3f3aba4",
"assets/assets/icons/setting.svg": "02cf0377ea110412dcb07390f2b43151",
"assets/assets/icons/user.svg": "f86f2b489ef70f5670667a460bb3f6e6",
"assets/assets/icons/users.svg": "91961992439dbe2abd74e8adf4e60f0d",
"assets/assets/icons/logouzita_maskable.png": "cbb783199dfa633f85587770ef324398",
"assets/assets/drawer_small_phone.jpg": "d23fa651c08811645a6f04f8cee914e8",
"assets/assets/drawer_big_phone.jpg": "ee6c4b848486eb19a37134c73a942036",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "33b7d9392238c04c131b6ce224e13711",
"assets/fonts/MaterialIcons-Regular.otf": "b74465e81748d2cc3792a082d6a3b898",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/AssetManifest.json": "0290d69d4ebed64e3a17c27465d60b1c",
"assets/AssetManifest.bin": "f98ae556a1eaa856d51b16aaeec0d9d0",
"assets/AssetManifest.bin.json": "69f806ade41e3bc9180a53587ccc0480",
"assets/FontManifest.json": "2838e09e9e8724a23a1a1767309356ec",
"assets/NOTICES": "e3168da64b359fcdc32cbdee98f6d558",
"favicon.png": "a352ffe434ae27c8eb30a6515d2270a7",
"manifest.json": "50c694eae1a6d2cd643be0d73a620dbc",
"icons/Icon-512.png": "942a4f09d85aa015715636f0a85182fc",
"icons/Icon-maskable-192.png": "3b3d681812d5c1368b0be2f45e3d005e",
"icons/Icon-maskable-512.png": "942a4f09d85aa015715636f0a85182fc",
"icons/Icon-192.png": "3b3d681812d5c1368b0be2f45e3d005e",
"icons/logouzita.png": "00677e146c5d7b837dc8b934806785c5",
"icons/apple-touch-icon-180x180.png": "0e2d63302284796a2641993562058985",
"icons/apple-touch-icon-167x167.png": "dc10a6109b0d8d8b3fbee8a5e687126f",
"icons/apple-touch-icon-152x152.png": "ae731ff380449b5f8316eb5715fca10b",
"icons/apple-touch-icon-120x120.png": "14a3bdb65ea02158c929b9f2c031f4e8",
"icons/Icon-maskable-36.png": "eb06ac3b9192554ce3464c58296006f8",
"icons/Icon-maskable-48.png": "3fcb4911817007027ec996f57af7f207",
"icons/Icon-maskable-72.png": "b7e1fe9ddbb911eaf4ebbaae18f553c2",
"icons/Icon-maskable-96.png": "402cc7107fd6ec7181773a206bfe1d9a",
"icons/Icon-maskable-128.png": "8e66adc8332c3ffb5ae9553524eec439",
"icons/Icon-maskable-144.png": "5225d71a5f9224fb3f89229cdbaa9919",
"icons/Icon-maskable-152.png": "16c24be41db26c2398ec0fbdfd056a47",
"icons/Icon-maskable-180.png": "5323f045e0b92344d7d8b2ae930206c8",
"icons/Icon-maskable-256.png": "87ab8ec441ffaaa620362a1afe74c4ec",
"icons/Icon-maskable-384.png": "c1f8e3aa2c5c98df15c67e6f8250e7d9",
"404.html": "89292b678def8e00767db955b5e485a1"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
